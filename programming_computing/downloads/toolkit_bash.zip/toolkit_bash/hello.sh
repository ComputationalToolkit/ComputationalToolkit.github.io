#!/bin/bash

# Print to the terminal
echo 'Hello World!'

exit
