#!/bin/bash

# Task 2:
# Run program.sh in each job directory  

#--Start of code--

# Program file name

# Loop over folders starting with 'job_'
  
  # Move into the folder

  # Run the program

  # Move out of the folder


#--End of script--
exit
