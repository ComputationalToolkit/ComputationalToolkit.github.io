#!/bin/bash

# Task 3:
# Sort jobs into two category folders, 'div2' and 'not2',
# each containing the job_n folders where the result 
# is and is not divisible by 2 respectively.

#--Start of code--

# Output file name

# Make folders for the two catagories

# Loop over folders starting with 'job_'

  # Check if outfile contains 'not divisible' in it.
  
    # If true, move the job folder into the 'not divisible' category
    
    # If false, move the job folder into the 'divisible' category

#--End of script--
exit
