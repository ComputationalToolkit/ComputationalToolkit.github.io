#!/bin/bash

# Task 2:
# Run program.sh in each job directory  

#--Start of code--

# Program file name
fprog='program.sh'

# Loop over folders starting with 'job_'
for dir in job_*
do
  # Move into the folder
  cd $dir

  # Run the program
  bash $fprog
  echo "Ran ${dir}."

  # Move out of the folder
  cd ..
done


#--End of script--
exit
