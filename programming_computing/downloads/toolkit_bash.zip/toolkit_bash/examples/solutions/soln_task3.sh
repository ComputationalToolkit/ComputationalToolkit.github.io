#!/bin/bash

# Task 3:
# Sort jobs into two category folders, 'div2' and 'not2',
# each containing the job_n folders where the result 
# is and is not divisible by 2 respectively.

#--Start of code--

# Output file name
fout='out.txt'

# Make folders for the two catagories
div2='div2'
not2='not2'
mkdir $div2
mkdir $not2

# Loop over folders starting with 'job_'
for dir in job_*
do
  # Check if outfile contains 'not divisible' in it.
  if grep -q 'not divisible' $dir/$fout
  then
    # If true, move the job folder into the 'not divisible' category
    mv $dir $not2/.
  else
    # If false, move the job folder into the 'divisible' category
    mv $dir $div2/.
  fi
    # Notify user of the status
    echo "Sorted ${dir}."
done


#--End of script--
exit
