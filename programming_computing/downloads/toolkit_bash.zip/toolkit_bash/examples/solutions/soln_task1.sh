#!/bin/bash

# Task 1:
# Make program.sh input files for  n=1,2,3,4,5,6 
# each in its own distinct folder named job_n .

#--Start of code--

# Program file name
fprog='program.sh'

# Loop over input values
for n in {1..6}
do

  # Folder name
  dir="job_${n}"

  # Make folder 
  mkdir $dir

  # Copy the program file into if
  cp $fprog $dir

  # Modify the input value
  cd $dir
  sed -i "s/n=1/n=${n}/g" $fprog
  cd ..

  # Notify user
  echo "Folder job_${n} ready."

done


#--End of script--
exit
