#!/bin/bash

# Task 4:
# Extract results for 'Square' from the jobs where n is divisible by 2.
# Save results to a file called 'square.txt'.

#--Start of code--

# Set filenames
fout='out.txt'
fres='square.txt'

# Folder with the divisible jobs
div2='div2'

# Extract and save results
grep 'Square' $div2/job_*/$fout > $fres

#--End of script--
exit
