#!/bin/bash

# Brief:
# This program checkes if input interger n is divisble by 2. 
# If true, it finds the n^. Results are saved to file out.txt.

# Set input n
n=1

# Set output file name
fout='out.txt'

# Check if n is divisible by 2
mod=$(( n%2 )) # modulo
if [ $mod -eq 0 ] 
then 
  echo 'This integer is divisible by 2.' > $fout
  sq=$(( n*n )) # multiply
  echo "Square = ${sq}" >> $fout # append to outfile
else
  echo 'This integer is not divisible by 2.' > $fout
fi

#--End of program--
exit
