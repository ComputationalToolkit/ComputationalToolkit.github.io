#!/bin/bash

# Task 1:
# Make program.sh input files for  n=1,2,3,4,5,6 
# each in its own distinct folder named job_n .

#--Start of code--

# Program file name
fprog='program.sh'

# Loop over input values
for n in {1..6}
do
  # Set folder name
  dir="job_${n}"

  # Make the folder
  mkdir $dir

  # Copy the program file into it
  cp $fprog $dir

  # Modify input value in its program.sh
  sed -i "s/n=1/n=${n}/g" $dir/$fprog

  # Notify user
  echo "Folder ${dir} ready."
done

#--End of script--
exit
